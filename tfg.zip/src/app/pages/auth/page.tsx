"use client";
import { signIn } from 'next-auth/react';


export default function SignIn() {
  return (
    <div className="flex items-center justify-center h-screen">
      <button
        onClick={() => signIn('google')}
        className="px-4 py-2 bg-blue-500 text-white rounded"
      >
        Sign in with Google
      </button>
    </div>
  );
}





