"use client";

import { signIn, signOut, useSession } from "next-auth/react";

export default function LoginButton() {
  const { data: session } = useSession();

  return session ? (
    <button onClick={() => signOut()}>Cerrar sesión</button>
  ) : (
    <button onClick={() => signIn("google")}>Iniciar sesión con Google</button>
  );
}
